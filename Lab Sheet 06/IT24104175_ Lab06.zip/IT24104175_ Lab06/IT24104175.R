setwd("C://Users//nitha//OneDrive//Desktop//IT24104175_ Lab06")

cat("----- Exercise Q1 (IT company) -----\n")

# Parameters
n <- 50
p <- 0.85

# i) Distribution
cat("Q1.i) Distribution: X ~ Binomial(n = ", n, ", p = ", p, ")\n", sep="")

# ii) Probability at least 47 students passed (P(X >= 47))
prob_q1_atleast47 <- 1 - pbinom(46, size = n, prob = p)
cat(sprintf("Q1.ii) P(X >= 47) = %.10f\n", prob_q1_atleast47))

cat("\n----- Exercise Q2 (Call center) -----\n")

# Parameters
lambda <- 12

# i) Random variable
cat("Q2.i) Random variable X = number of calls received in one hour\n")

# ii) Distribution
cat("Q2.ii) Distribution: X ~ Poisson(lambda = ", lambda, ")\n", sep="")

# iii) Probability exactly 15 calls
prob_q2_eq15 <- dpois(15, lambda = lambda)
cat(sprintf("Q2.iii) P(X = 15) = %.10f\n", prob_q2_eq15))

